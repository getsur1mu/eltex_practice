#!/bin/bash

LOG_FILE="cuckoo.log"
PIPE="/tmp/run/cuckoo.pid"

mkdir -p /tmp/run

rm -f "$PIPE"
mkfifo "$PIPE"

echo "$(date '+%Y-%m-%d %H:%M:%S') Startup!" >> "$LOG_FILE"

trap 'echo "$(date "+%Y-%m-%d %H:%M:%S") Shutdown!" >> "$LOG_FILE"; rm -f "$PIPE"; exit 0' SIGINT

while read -r request; do
	if [[ "$request" =~ ^([^:]+):.*how\ much\ time.*$ ]]; then
		part="${BASH_REMATCH[1]}"
		if [[ "$part" =~ ^([^[]+)\[([0-9]+)\]$ ]]; then
        	NAME="${BASH_REMATCH[1]}"
        	PID="${BASH_REMATCH[2]}"
		N=$(( RANDOM % 9 + 2))
		echo "$(date '+%Y-%m-%d %H:%M:%S') ${NAME}[${PID}] ${N}" >> "$LOG_FILE"
    		fi
	fi
done < "$PIPE"
