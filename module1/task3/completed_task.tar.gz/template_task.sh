#!/bin/bash

SCRIPT_NAME=$(basename "$0")
if [[ "$SCRIPT_NAME" == "template_task.sh" ]]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi
LOG_FILE="report_${SCRIPT_NAME}.log"
CUCKOO_LOG="cuckoo.log"
PIPE="/tmp/run/cuckoo.pid"

log_message() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] $1" >> "$LOG_FILE"
}

log_message "Скрипт запущен"
if [[ ! -p "$PIPE" ]]; then
    log_message "Ошибка: именованный канал $PIPE не найден"
    echo "Ошибка: cuckoo.sh не запущен?" >&2
    exit 1
fi

REQUEST="${SCRIPT_NAME}[$$]: how much time do I have?"
echo "$REQUEST" > "$PIPE"
sleep 0.5

CUCKOO_RESPONSE=$(grep "\[$$\]" "$CUCKOO_LOG" | tail -1)

if [[ -z "$CUCKOO_RESPONSE" ]]; then
    log_message "Ошибка: не найден ответ от cuckoo для PID $$"
    echo "Ошибка: cuckoo не ответил" >&2
    exit 1
fi
N=$(echo "$CUCKOO_RESPONSE" | awk '{print $NF}')
if [[ ! "$N" =~ ^[0-9]+$ ]] || [[ "$N" -lt 2 ]] || [[ "$N" -gt 10 ]]; then
    log_message "Ошибка: получен некорректный ответ от cuckoo: '$N'"
    echo "Ошибка: cuckoo вернул некорректное значение" >&2
    exit 1
fi
log_message "Получено время ожидания: $N секунд"
sleep "$N"
log_message "Скрипт завершился, работал $N секунд"
echo "Скрипт выполнен. Ожидал $N секунд."
exit 0
