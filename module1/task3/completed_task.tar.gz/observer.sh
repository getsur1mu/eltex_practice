#!/bin/bash

CONFIG_FILE="observer.conf"
LOG_FILE="observer.log"

log_message() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] $1" >> "$LOG_FILE"
}

if [[ ! -f "$CONFIG_FILE" ]]; then
    log_message "Ошибка: файл конфигурации $CONFIG_FILE не найден"
    echo "Ошибка: observer.conf не существует"
    exit 1
fi

log_message "Наблюдатель запущен"

while IFS= read -r script_name; do
    [[ -z "$script_name" ]] && continue
    [[ "$script_name" =~ ^#.*$ ]] && continue
    script_name=$(echo "$script_name" | xargs)

    found=0
    for pid in /proc/[0-9]*; do
        if [[ -f "$pid/comm" ]]; then
            proc_name=$(cat "$pid/comm" 2>/dev/null)
            if [[ "$proc_name" == "$script_name" ]]; then
                found=1
                break
            fi
        fi
    done

    if [[ $found -eq 0 ]]; then
        if [[ -f "./$script_name" ]]; then
            nohup ./"$script_name" > /dev/null 2>&1 &
            log_message "Перезапущен скрипт: $script_name (PID: $!)"
        else
            log_message "Ошибка: скрипт $script_name не найден в текущем каталоге"
        fi
    fi
done < "$CONFIG_FILE"

log_message "Наблюдатель завершил проверку"
